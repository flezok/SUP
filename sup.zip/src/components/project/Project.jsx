import { useState } from 'react';

import './project.scss'

const Project = () => {

    return (
        <section className='project'>
            <h2 className='account__title'>
                Доска проекта
            </h2>

            <div className='project__header'>
                <div className="project__name project__header-item">
                    <p className="project__name-text">
                        Разработка приложения
                    </p>
                </div>

                <div className="project__team project__header-item">
                    <div className="project__team-images">
                        <div className="project__team-wrapper-img">
                            <img className="project__team-img" src="../../../public/images/avatar1.png">

                            </img>
                        </div>
                        <div className="project__team-wrapper-img">
                            <img className="project__team-img" src="../../../public/images/avatar2.png">

                            </img>
                        </div>
                        <div className="project__team-wrapper-img">
                            <img className="project__team-img" src="../../../public/images/avatar3.png">

                            </img>
                        </div>
                    </div>

                    <button className='project__team-btn'>
                        <p className='project__team-btn-text'>
                            Добавить участника
                        </p>
                    </button>
                </div>
                
                <div className="project__setting project__header-item">
                    <button className="project__setting-btn">
                        <p className="project__setting-text">
                            Настройки
                        </p>
                    </button>
                </div>

                <div className="project__date">
                    <div className="project__date-created project__date-container">
                        <p className='project__date-action'>
                            Создан:
                        </p>
                        <p className='project__date-text'>
                            янв 04, 2025
                        </p>
                    </div>
                    <div className="project__date-deadline project__date-container">
                        <p className='project__date-action'>
                            Срок:
                        </p>
                        <p className='project__date-text'>
                            сен 25, 2025
                        </p>
                    </div>
                </div>
            </div>

            <div className="project__tools">
                <div className="project__inner">
                    <div className="project__tools-search">
                        <input className="project__tools-input" type="text" placeholder='Поиск'></input>
                    </div>
                    <div className="project__tools-sort">
                        <button className="project__sort-btn">
                            <p className="project__sort-btn-text">
                                Стандартная
                            </p>
                        </button>
                        {/* <ul class="dropdown__menu">
                            <li class="dropdown__item"><a href="#">Пункт 1</a></li>
                            <li class="dropdown__item"><a href="#">Пункт 2</a></li>
                            <li class="dropdown__item"><a href="#">Пункт 3</a></li>
                        </ul> */}
                    </div>
                </div>
                <button className='project__member'>
                    <p className='project__member-text'>
                        Сотрудники
                    </p>
                </button>
            </div>

            <div className="project__container">
                <div className="project__container-wrapper">
                <div className="project__tasks-wrapper">

                    <div className='project__tasks'>
                        <div className="project__tasks-stage">
                            <div className='project__stage-wrapper'>
                                <div className='project__stage-color'></div>
                                <p className='project__stage-text'>
                                    В ожидании
                                </p>
                            </div>
                            <button className='project__stage-btn'></button>
                        </div>

                        <div className="project__task">
                            <img className="project__task-img" src="../../../public/images/task.png"></img>
                            <div className="project__task-deadline">
                                <p className="project__task-deadline-text">
                                    06 фев 2025
                                </p>
                            </div>
                            <h3 className='project__task-title'>
                                Название крутой задачи
                            </h3>
                            <p className="project__task-text">
                                Эта крутая задача с очень длинным описанием тут я что-то написал про эту задачу она реально суперская
                            </p>
                            <div className="project__task-progress">
                                <p className="project__task-progress-text">
                                    Прогресс:
                                </p>
                                <p className="project__task-progress-count">
                                    0/6
                                </p>
                            </div>
                            <div className='project__task-footer'>
                                <div className="task__footer-stats">
                                    <div className="task__footer-stat task__footer-view">
                                        <p className="task__footer-count">
                                            4
                                        </p>
                                    </div>
                                    <div className="task__footer-stat task__footer-comment">
                                        <p className="task__footer-count">
                                            15        
                                        </p>
                                    </div>
                                </div>

                                <div className='task__footer-images'>
                                    <div className="project__team-images">
                                        <div className="project__team-wrapper-img">
                                            <img className="project__team-img" src="../../../public/images/avatar1.png">

                                            </img>
                                        </div>
                                        <div className="project__team-wrapper-img">
                                            <img className="project__team-img" src="../../../public/images/avatar2.png">

                                            </img>
                                        </div>
                                        <div className="project__team-wrapper-img">
                                            <img className="project__team-img" src="../../../public/images/avatar3.png">

                                            </img>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="project__task">
                            <img className="project__task-img" src="../../../public/images/task.png"></img>
                            <div className="project__task-deadline">
                                <p className="project__task-deadline-text">
                                    06 фев 2025
                                </p>
                            </div>
                            <h3 className='project__task-title'>
                                Название крутой задачи
                            </h3>
                            <p className="project__task-text">
                                Эта крутая задача с очень длинным описанием тут я что-то написал про эту задачу она реально суперская
                            </p>
                            <div className="project__task-progress">
                                <p className="project__task-progress-text">
                                    Прогресс:
                                </p>
                                <p className="project__task-progress-count">
                                    0/6
                                </p>
                            </div>
                            <div className='project__task-footer'>
                                <div className="task__footer-stats">
                                    <div className="task__footer-stat task__footer-view">
                                        <p className="task__footer-count">
                                            4
                                        </p>
                                    </div>
                                    <div className="task__footer-stat task__footer-comment">
                                        <p className="task__footer-count">
                                            15        
                                        </p>
                                    </div>
                                </div>

                                <div className='task__footer-images'>
                                    <div className="project__team-images">
                                        <div className="project__team-wrapper-img">
                                            <img className="project__team-img" src="../../../public/images/avatar1.png">

                                            </img>
                                        </div>
                                        <div className="project__team-wrapper-img">
                                            <img className="project__team-img" src="../../../public/images/avatar2.png">

                                            </img>
                                        </div>
                                        <div className="project__team-wrapper-img">
                                            <img className="project__team-img" src="../../../public/images/avatar3.png">

                                            </img>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <button className="project__tasks-btn">
                            <p className='project__tasks-btn-text'>
                                Новая задача
                            </p>
                        </button>
                    </div>

                    <div className='project__tasks'>
                        <div className="project__tasks-stage">
                            <div className='project__stage-wrapper'>
                                <div className='project__stage-color'></div>
                                <p className='project__stage-text'>
                                    В ожидании
                                </p>
                            </div>
                            <button className='project__stage-btn'></button>
                        </div>

                        <div className="project__task">
                            <img className="project__task-img" src="../../../public/images/task.png"></img>
                            <div className="project__task-deadline">
                                <p className="project__task-deadline-text">
                                    06 фев 2025
                                </p>
                            </div>
                            <h3 className='project__task-title'>
                                Название крутой задачи
                            </h3>
                            <p className="project__task-text">
                                Эта крутая задача с очень длинным описанием тут я что-то написал про эту задачу она реально суперская
                            </p>
                            <div className="project__task-progress">
                                <p className="project__task-progress-text">
                                    Прогресс:
                                </p>
                                <p className="project__task-progress-count">
                                    0/6
                                </p>
                            </div>
                            <div className='project__task-footer'>
                                <div className="task__footer-stats">
                                    <div className="task__footer-stat task__footer-view">
                                        <p className="task__footer-count">
                                            4
                                        </p>
                                    </div>
                                    <div className="task__footer-stat task__footer-comment">
                                        <p className="task__footer-count">
                                            15        
                                        </p>
                                    </div>
                                </div>

                                <div className='task__footer-images'>
                                    <div className="project__team-images">
                                        <div className="project__team-wrapper-img">
                                            <img className="project__team-img" src="../../../public/images/avatar1.png">

                                            </img>
                                        </div>
                                        <div className="project__team-wrapper-img">
                                            <img className="project__team-img" src="../../../public/images/avatar2.png">

                                            </img>
                                        </div>
                                        <div className="project__team-wrapper-img">
                                            <img className="project__team-img" src="../../../public/images/avatar3.png">

                                            </img>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="project__task">
                            <img className="project__task-img" src="../../../public/images/task.png"></img>
                            <div className="project__task-deadline">
                                <p className="project__task-deadline-text">
                                    06 фев 2025
                                </p>
                            </div>
                            <h3 className='project__task-title'>
                                Название крутой задачи
                            </h3>
                            <p className="project__task-text">
                                Эта крутая задача с очень длинным описанием тут я что-то написал про эту задачу она реально суперская
                            </p>
                            <div className="project__task-progress">
                                <p className="project__task-progress-text">
                                    Прогресс:
                                </p>
                                <p className="project__task-progress-count">
                                    0/6
                                </p>
                            </div>
                            <div className='project__task-footer'>
                                <div className="task__footer-stats">
                                    <div className="task__footer-stat task__footer-view">
                                        <p className="task__footer-count">
                                            4
                                        </p>
                                    </div>
                                    <div className="task__footer-stat task__footer-comment">
                                        <p className="task__footer-count">
                                            15        
                                        </p>
                                    </div>
                                </div>

                                <div className='task__footer-images'>
                                    <div className="project__team-images">
                                        <div className="project__team-wrapper-img">
                                            <img className="project__team-img" src="../../../public/images/avatar1.png">

                                            </img>
                                        </div>
                                        <div className="project__team-wrapper-img">
                                            <img className="project__team-img" src="../../../public/images/avatar2.png">

                                            </img>
                                        </div>
                                        <div className="project__team-wrapper-img">
                                            <img className="project__team-img" src="../../../public/images/avatar3.png">

                                            </img>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <button className="project__tasks-btn">
                            <p className='project__tasks-btn-text'>
                                Новая задача
                            </p>
                        </button>
                    </div>

                    

                </div>

                <button className="project__btn">
                    <p className='project__btn-text'>
                        Новый этап
                    </p>
                </button>
                </div>
            </div>
        </section>
    )

}

export default Project